﻿Public Class VB_Demo_App

    Private RecipeDGV As New DataGridView
    Private Const vbNL As String = vbNewLine

    Private Sub VB_Demo_App_Load(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Load

        Dim i, j As Integer

        Me.Controls.Add(Me.RecipeDGV)

        Me.RecipeDGV.ColumnHeadersDefaultCellStyle.Font = New Font(Font.FontFamily, 8.25, FontStyle.Bold)
        Me.RecipeDGV.Size = New Size(1100, 331)

        '   Form width

        Me.Width = 1100

        Me.RecipeDGV.Parent = Me
        Me.RecipeDGV.Visible = True
        Me.RecipeDGV.AllowUserToAddRows = False
        Me.RecipeDGV.AllowUserToResizeRows = False
        Me.RecipeDGV.AllowUserToDeleteRows = False
        Me.RecipeDGV.AllowUserToOrderColumns = False
        Me.RecipeDGV.AllowUserToResizeColumns = False
        Me.RecipeDGV.SelectionMode = DataGridViewSelectionMode.FullRowSelect

        '  Build a 2-D string array; columnHeaderArray[][0] has
        '  the DGV column name; columnHeaderArray[][1] has the
        '  DGV column header text . . .

        Dim columnHeaderArray(,) As String =
            New String(,) {
                            {"ROW_NUM", "ROW NUMBER"},
                            {"CATEGORY_NAME", "CATEGORY NAME"},
                            {"RECIPE_NAME", "RECIPE NAME"},
                            {"RECIPE_TEXT", "RECIPE TEXT"},
                            {"RECIPE_ID", "RECIPE ID"},
                            {"CATEGORY_ID", "CATEGORY ID"},
                            {"CREATE_DATE", "CREATE DATE"},
                            {"LAST_UPDATE_DATE", "DATE OF LAST UPDATE"}
                          }

        '  This array has the DGV column width values . . .

        Dim widthArray = New Integer() {95, 80, 140, 289, 65, 84, 165, 155}

        '   Build out the RecipeDGV columns . . .

        For i = 0 To 7

            Me.RecipeDGV.Columns.Add(columnHeaderArray(i, 0), columnHeaderArray(i, 1))
            Me.RecipeDGV.Columns(i).HeaderCell.Style.Alignment = DataGridViewContentAlignment.MiddleCenter
            Me.RecipeDGV.Columns(i).SortMode = DataGridViewColumnSortMode.NotSortable

            '   Set alignment for columns 0 and columns 4 to 7. Datagridview columns
            '   default to left aligned; to look for zero <-> false, cast 0 as a
            '   boolean . . .

            If (((i > 3) And (i < 6)) OrElse (Not CBool(i))) Then
                Me.RecipeDGV.Columns(i).DefaultCellStyle.Alignment = DataGridViewContentAlignment.MiddleRight
            End If

            Me.RecipeDGV.Columns(i).Width = widthArray(i)
        Next

        '   Build DGVRecordArray has a 1-D array OF 1-D string
        '   arrays - a jagged array . . .

        '   "Original" values . . .

        '   RECIPE 1 COL 2  -> "A TESTED RECIPE"
        '   RECIPE 7 COL 2  -> "CHOCOLATE RECIPE"
        '   RECIPE 11 COL 2  -> "RECIPE RETESTING"

        Dim DGVRecordArray(,) As String =
            New String(,) {
                            {"1", "CATEGORY_1", "-2", "The tested recipe goes here." + vbNL + vbNL + "It has only two lines.", "17", "500", "FEBRUARY 12, 2006", "JANUARY 25, 2008"},
                            {"2", "CATEGORY_1", "RECIPE 25", "For RECIPE 25, look for three lines" + vbNL + vbNL + "here" + vbNL + vbNL + "and here.", "19", "500", "JANUARY 15, 2008 10:45:22", "APRIL 02, 2008"},
                            {"3", "CATEGORY_1", "BISCUIT RECIPE", "This biscuit recipe worked well and it had" + vbNL + vbNL + "a few" + vbNL + vbNL + "lines.", "20", "500", "JANUARY 15, 2008 10:45:22", "JANUARY 15, 2008"},
                            {"4", "CATEGORY_1", "PUBLISHED RECIPE", "A published recipe" + vbNL + vbNL + "with more lines" + vbNL + vbNL + "here" + vbNL + vbNL + "and here" + vbNL + vbNL + "and here.", "23", "500", "NOVEMBER 01, 2004", "JANUARY 19, 2008"},
                            {"5", "CATEGORY_1", "RECIPE FOR STEW", "The stew recipe should have beef or lamb.", "27", "500", "MARCH 22, 2007", "APRIL 15, 2008"},
                            {"6", "CATEGORY_1", "TESTED RECIPE", "Recipe testing done" + vbNL + vbNL + "for this" + vbNL + vbNL + "recipe" + vbNL + vbNL + "as verified records. . .", "29", "500", "JANUARY 11, 2008", "JANUARY 14, 2008"},
                            {"7", "CATEGORY_1", "83.991", "Sample chocolate cake recipe" + vbNL + vbNL + "Line 2" + vbNL + vbNL + "Next line here.", "30", "500", "DECEMBER 10, 2007", "JANUARY 15, 2008"},
                            {"8", "CATEGORY_1", "AAAAAAA TEST RECIPE", "This is a test." + vbNL + vbNL + "Another test." + vbNL + vbNL + "Another line." + vbNL + vbNL + "Yet another line." + vbNL + vbNL + "Line 4." + vbNL + vbNL + "Line 5." + vbNL + vbNL + "Line 6.", "4906", "500", "JANUARY 15, 2008", "JANUARY 15, 2008"},
                            {"9", "CATEGORY_2", "COOKIE RECIPE", " One original cookie recipe" + vbNL + vbNL + "on multiple lines" + vbNL + vbNL + "of text.", "3378", "545", "OCTOBER 01, 2006", "JANUARY 15, 2008"},
                            {"10", "CATEGORY_1", "RECIPE RETEST", "This is line 1." + vbNL + vbNL + "This is line 2." + vbNL + "And line 3.", "4988", "500", "AUGUST 29, 2007", "JANUARY 15, 2008"},
                            {"11", "CATEGORY_2", "83.992", "This is a retest." + vbNL + vbNL + "Line 1 1/2, and line 1 3/4." + vbNL + vbNL + "Line 2." + vbNL + vbNL + "Line 2.5 here!" + vbNL + vbNL + "Line 3." + vbNL + vbNL + "Line 4.", "4989", "545", "JULY 10, 2007", "MARCH 07, 2008"},
                            {"12", "CATEGORY_2", "A TESTED RECIPE", "Retesting the application here." + vbNL + vbNL + "Line 2." + vbNL + "Line 3." + vbNL + vbNL + "Line 5.", "4987", "545", "MAY 09, 2006", "JANUARY 15, 2008"},
                            {"13", "CATEGORY_2", "A TESTED RECIPE", "For example" + vbNL + vbNL + "this is an example recipe" + vbNL + vbNL + "here" + vbNL + vbNL + "in this record", "4990", "545", "JUNE 2, 2003", "JUNE 25, 2008"},
                            {"14", "CATEGORY_2", "POTENTIAL RECIPE", "This is line 1." + vbNL + vbNL + "This is line 2." + vbNL + "Line 3." + vbNL + vbNL + "Line 4.5." + vbNL + vbNL + "Line 4!", "3245", "545", "APRIL 18, 2000", "JANUARY 15, 2008"}
                          }

        '   Load the DGVRecordArray values into RecipeDGV . . .

        For i = 0 To 13
            Me.RecipeDGV.Rows.Add()
            For j = 0 To 7
                Me.RecipeDGV.Item(j, i).Value = DGVRecordArray(i, j).ToString
            Next j
        Next i

        Me.RecipeDGV.ColumnHeadersHeightSizeMode = DataGridViewColumnHeadersHeightSizeMode.DisableResizing
        Me.RecipeDGV.RowHeadersVisible = False

    End Sub

    Private Sub btn_exit_Click(sender As Object, e As EventArgs) Handles btn_exit.Click

        Me.Close()

    End Sub

    Private Sub btn_load_RTB_Click(sender As Object, e As EventArgs) Handles btn_load_RTB.Click

        If (Me.RecipeDGV.SelectedRows.Count < 1) Then

            '   Leave the method if RecipeDGV has no selected rows . . .

            MsgBox("Please pick at least one row in the DataGridView.", MsgBoxStyle.OkOnly, "No DataGridView rows selected") '"No DataGridView rows selected", MsgBoxStyle.OkOnly)
            Return
        End If

        Dim localDGVSRC As DataGridViewSelectedRowCollection

        Dim recipe_text As String = ""
        Dim recipe_name As String = ""
        Dim i = 0, j As Integer
        Dim page_separator_string As String

        '   String page_separator_string will simulate a
        '   page break in the rich textbox text. Declare
        '   a new constant
        '
        '       vbNL
        '
        '   as a substitute for
        '
        '       vbNewLine
        '
        '   to save character volume here . . .

        page_separator_string = vbNL + vbNL + "                     ____________"
        page_separator_string += vbNL + "         ________________________" + vbNL
        page_separator_string += "                     ____________" + vbNL + vbNL + vbNL

        localDGVSRC = Me.RecipeDGV.SelectedRows

        '   The combinedDGVRecordArray is a 1-D array of single DGV record arrays.
        '   Array indexing starts at zero (0), so subtract one from
        '   RecipeDGV.SelectedRows.Count . . .

        Dim combinedDGVRecordArray()() As String = New String(Me.RecipeDGV.SelectedRows.Count - 1)() {}

        i = 0

        '   Place all selected row cells in combinedDGVRecordArray and initialize i. Use variable
        '   i to loop through the selected DGV source rows . . .

        For Each row As DataGridViewRow In Me.RecipeDGV.SelectedRows.Cast(Of DataGridViewRow)()

            combinedDGVRecordArray(i) = New String(Me.RecipeDGV.Columns.Count - 1) {}
            For j = 0 To (Me.RecipeDGV.Columns.Count - 1)
                combinedDGVRecordArray(i)(j) = row.Cells(j).Value
            Next

            '   Increment i to move to the next selected DGV source row . . .

            i += 1

        Next

        '   Dim / new a ColumnSorter object. The class wants the column
        '   numbers as strings. The column numbering starts at 0 (zero)
        '   and to flag descending order for a column, prefix the number
        '   with a hyphen
        '
        '       -
        '
        '   character. Use this even for column 0 (zero) . . .

        '        Dim column_comparer As ColumnSorter = New ColumnSorter("1", "-0")

        Dim column_comparer As ColumnSorter = New ColumnSorter("1", "-0") ' ("2") ' ("1", "-0")

        Array.Sort(combinedDGVRecordArray, column_comparer)

        '   Loop through every picked row in recipeDGV. In the
        '   rows, Item(3) has the recipe text. Item(2) has the
        '   recipe name string. Add a character that simulates
        '   a hard page break after the recipe text . . .

        For i = 0 To combinedDGVRecordArray.GetUpperBound(0)

            recipe_name = combinedDGVRecordArray(i)(2)
            recipe_text += recipe_name + vbNewLine + vbNewLine + combinedDGVRecordArray(i)(3) + page_separator_string

        Next

        '   Delete the last / ending page_separator_string component
        '   characters in the recipe text, place that text in the
        '   relevant form / control, and set controls / forms as
        '   appropriate . . .

        textForm1.recipe_text = recipe_text.Substring(0, (Len(recipe_text) - 113))

        Me.btn_exit.Enabled = False
        Me.btn_load_RTB.Enabled = False

        textForm1.Show()

    End Sub
End Class