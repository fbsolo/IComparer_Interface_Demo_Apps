﻿Public Class textForm1

    Private localRTB As New RichTextBox
    Private local_recipe_text As String

    Friend WriteOnly Property recipe_text() As String

        '   This property has the text value to place
        '   in the localRTB RichTextBox . . .

        Set(ByVal value As String)
            local_recipe_text = value
        End Set

    End Property

    Private Sub textForm1_Load(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Load

        Me.Controls.Add(Me.localRTB)
        Me.localRTB.Size = New Size(983, 500)
        Me.localRTB.ScrollBars = RichTextBoxScrollBars.Vertical

        '   Set the form width . . .

        Me.Width = 1100

        '   Place the local_recipe_text property
        '   in the RichTextBox . . .

        Me.localRTB.Text = Me.local_recipe_text

    End Sub

    Private Sub btn_exit_Click(sender As Object, e As EventArgs) Handles btn_exit.Click

        VB_Demo_App.btn_exit.Enabled = True
        VB_Demo_App.btn_load_RTB.Enabled = True

        Me.Close()

    End Sub

End Class