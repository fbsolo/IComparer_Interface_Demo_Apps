﻿Public Class ColumnSorter
    Implements IComparer

    '   This property has the column numbers, as numeric
    '   strings, for the sorting criteria. A leading "-"
    '   character (a hyphen) flags DESCENDING order. This
    '   applies to column 0 (zero) . . .

    Private sort_Columns() As String

    Public Sub New(ByVal ParamArray columns() As String)

        sort_Columns = columns

    End Sub

    Public Function Compare(x As Object, y As Object) As Integer Implements _
        System.Collections.IComparer.Compare

        Dim colVal, sortSign As String
        Dim col As Integer

        '   Loop through the sort_Columns array . . .

        For i As Integer = 0 To sort_Columns.GetUpperBound(0)

            '   For the colVal array item,
            '   first find the sign . . .

            colVal = sort_Columns(i)
            sortSign = IIf((Left(colVal, 1) = "-"), "-", "+")

            '   Remove any leading sign from the "column number"
            '   string, convert that numeric string to an integer,
            '   and place that integer value in the
            '
            '       col
            '
            '   variable . . .

            If (sortSign = "-") Then
                col = Convert.ToInt16(Right(colVal, (Len(colVal) - 1)))
            Else
                col = Convert.ToInt16(colVal)
            End If

            If (IsNumeric(x(col)) And IsNumeric(y(col))) Then

                '   Conparing numerics . . .

                If sortSign = "-" Then

                    '   Descending sort. Case
                    '
                    '       x(col) = y(col)
                    '
                    '   will fall through to the
                    '   end of the function and
                    '   return 0 (zero) . . .

                    If CDec(x(col)) < CDec(y(col)) Then Return 1
                    If CDec(x(col)) > CDec(y(col)) Then Return -1

                Else

                    '   Ascending sort. Case
                    '
                    '       x(col) = y(col)
                    '
                    '   will fall through to the
                    '   end of the function and
                    '   return 0 (zero) . . .

                    If CDec(x(col)) < CDec(y(col)) Then Return -1
                    If CDec(x(col)) > CDec(y(col)) Then Return 1

                End If

            ElseIf (IsDate(x(col)) And IsDate(y(col))) Then

                '   Comparing datetimes . . .

                '   To compare two datetime string values,
                '   first convert them to Datetime
                '   variables . . .

                Dim dateTime1, dateTime2 As DateTime

                dateTime1 = DateTime.Parse(x(col))
                dateTime2 = DateTime.Parse(y(col))

                If sortSign = "-" Then

                    '   Descending sort. Case
                    '
                    '       dateTime1 = dateTime2
                    '
                    '   will fall through to the
                    '   end of the function and
                    '   return 0 (zero) . . .

                    If dateTime1 < dateTime2 Then Return 1
                    If dateTime1 > dateTime2 Then Return -1
                Else

                    '   Ascending sort. Case
                    '
                    '       dateTime1 = dateTime2
                    '
                    '   will fall through to the
                    '   end of the function and
                    '   return 0 (zero) . . .

                    If dateTime1 < dateTime2 Then Return -1
                    If dateTime1 > dateTime2 Then Return 1
                End If

            Else
                '   Comparing strings of other "types" . . .  

                If sortSign = "-" Then

                    '   Descending sort. Case
                    '
                    '       x(col) = y(col)
                    '
                    '   will fall through to the
                    '   end of the function and
                    '   return 0 (zero) . . .

                    If x(col) < y(col) Then Return 1
                    If x(col) > y(col) Then Return -1
                Else

                    '   Ascending sort. Case
                    '
                    '       x(col) = y(col)
                    '
                    '   will fall through to the
                    '   end of the function and
                    '   return 0 (zero) . . .

                    If x(col) < y(col) Then Return -1
                    If x(col) > y(col) Then Return 1
                End If

            End If
        Next i

        '   Default returned value . . .

        Return 0

    End Function
End Class