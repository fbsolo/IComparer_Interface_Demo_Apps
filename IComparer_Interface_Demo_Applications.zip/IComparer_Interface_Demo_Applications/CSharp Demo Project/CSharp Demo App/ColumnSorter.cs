﻿using System;
using System.Collections;

namespace CSharp_Demo_App
{
    public class ColumnSorter : IComparer {

        //  This property has the column numbers, as numeric
        //  strings, for the sorting criteria. A leading "-"
        //  character (a hyphen) flags DESCENDING order. This
        //  applies to column 0 (zero) . . .

        private string[] sort_Columns;

        public ColumnSorter(params string[] Columns)
        {
            //  Assign the Columns parameter
            //  to the private sort_Columns
            //  property . . .

            this.sort_Columns = Columns;
        }

        int IComparer.Compare(Object x, Object y)
        {
            string colVal, sortSign;
            string[] xStringArray, yStringArray;

            //  Parameters x and y come to the
            //  method as arrays of strings, so
            //  place the parameter values into
            //  string arrays . . .

            xStringArray = (string[])x;
            yStringArray = (string[])y;

            int col;

            //  Loop through the sort_Columns array . . .

            for (int i = 0; i < (sort_Columns.GetUpperBound(0) + 1); i++)
            {
                //   For the colVal array item,
                //   first find the sign . . .

                colVal = sort_Columns[i];
                sortSign = (colVal.Substring(0, 1) == "-") ? "-" : "+";

                //   Remove any leading sign from the "column number"
                //   string, convert that numeric string to an integer,
                //   and place that integer value in the
                //
                //       col
                //
                //   variable . . .

                col = (sortSign == "-") ? Convert.ToInt16(colVal.Substring(1, (colVal.Length - 1))) : Convert.ToInt16(colVal);

                //  C# doesn't have "clean" IsNumeric() or IsDate()
                //  functions, so use TryParse as a workaround . . .

                Decimal parseTestResultNum;
                DateTime parseTestDate;

                bool parseXColNum = Decimal.TryParse(xStringArray[col], out parseTestResultNum);
                bool parseYColNum = Decimal.TryParse(yStringArray[col], out parseTestResultNum);

                bool parseXColDate = DateTime.TryParse(xStringArray[col], out parseTestDate);
                bool parseYColDate = DateTime.TryParse(yStringArray[col], out parseTestDate);

                if (parseXColNum && parseYColNum)
                {
                    Decimal decXColVal = Convert.ToDecimal(xStringArray[col]);
                    Decimal decYColVal = Convert.ToDecimal(yStringArray[col]);

                    //  Comparing numerics . . .

                    if (sortSign == "-")
                    {
                        //   Descending sort. Case
                        //
                        //       decXColVal = decYColVal
                        //
                        //   will fall through to the
                        //   end of the function and
                        //   return 0 (zero) . . .

                        if (decXColVal < decYColVal)
                        {
                            return 1;
                        }

                        if (decXColVal > decYColVal)
                        {
                            return -1;
                        }
                    }
                    else
                    {
                        //   Ascending sort. Case
                        //
                        //       x(col) = y(col)
                        //
                        //   will fall through to the
                        //   end of the function and
                        //   return 0 (zero) . . .

                        if (decXColVal < decYColVal)
                        {
                            return -1;
                        }

                        if (decXColVal > decYColVal)
                        {
                            return 1;
                        }
                    }
                }
                else if (parseXColDate && parseYColDate)
                {
                    DateTime datetimeXColVal = Convert.ToDateTime(xStringArray[col]);
                    DateTime datetimeYColVal = Convert.ToDateTime(yStringArray[col]);

                    //  Comparing datetimes . . .

                    if (sortSign == "-")
                    {
                        //   Descending sort. Case
                        //
                        //       dateTime1 = dateTime2
                        //
                        //   will fall through to the
                        //   end of the function and
                        //   return 0 (zero) . . .

                        if (datetimeXColVal < datetimeYColVal)
                        {
                            return 1;
                        }

                        if (datetimeXColVal > datetimeYColVal)
                        {
                            return -1;
                        }
                    }
                    else
                    {
                        //   Ascending sort. Case
                        //
                        //       dateTime1 = dateTime2
                        //
                        //   will fall through to the
                        //   end of the function and
                        //   return 0 (zero) . . .

                        if (datetimeXColVal < datetimeYColVal)
                        {
                            return -1;
                        }

                        if (datetimeXColVal > datetimeYColVal)
                        {
                            return 1;
                        }
                    }
                }
                else
                {
                    //  Comparing strings of other "types" . . .

                    if (sortSign == "-")
                    {
                        //   Descending sort. Case
                        //
                        //       x(col) = y(col)
                        //
                        //   will fall through to the
                        //   end of the function and
                        //   return 0 (zero) . . .

                        if (string.Compare(xStringArray[col], yStringArray[col]) == -1)
                        {
                            //  xStringArray[col] < yStringArray[col]

                            return -1;
                        }

                        if (string.Compare(xStringArray[col], yStringArray[col]) == 1)
                        {
                            //  xStringArray[col] > yStringArray[col]

                            return 1;
                        }
                    }
                    else
                    {
                        //   Ascending sort. Case
                        //
                        //       x(col) = y(col)
                        //
                        //   will fall through to the
                        //   end of the function and
                        //   return 0 (zero) . . .

                        if (string.Compare(xStringArray[col], yStringArray[col]) == 1)
                        {
                            //  xStringArray[col] < yStringArray[col]

                            return 1;
                        }

                        if (string.Compare(xStringArray[col], yStringArray[col]) == -1)
                        {
                            //  xStringArray[col] > yStringArray[col]

                            return -1;
                        }
                    }
                }
            }

            //  Default returned value . . .

            return 0;
        }
    }
}