﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace CSharp_Demo_App
{
    public partial class CSharp_Demo_App : Form
    {
        private String csNL = Environment.NewLine;
        private DataGridView RecipeDGV = new DataGridView();

        public CSharp_Demo_App()
        {
            InitializeComponent();
        }

        private void CSharp_Demo_App_Load(object sender, EventArgs e)
        {
            int i, j;

            this.Controls.Add(this.RecipeDGV);

            this.RecipeDGV.ColumnHeadersDefaultCellStyle.Font = new Font(Font.FontFamily, 8.25f, FontStyle.Bold);
            this.RecipeDGV.Size = new Size(1100, 331);

            //  Form width

            this.Width = 1100;

            this.RecipeDGV.Parent = this;
            this.RecipeDGV.Visible = true;
            this.RecipeDGV.AllowUserToAddRows = false;
            this.RecipeDGV.AllowUserToResizeRows = false;
            this.RecipeDGV.AllowUserToDeleteRows = false;
            this.RecipeDGV.AllowUserToOrderColumns = false;
            this.RecipeDGV.AllowUserToResizeColumns = false;
            this.RecipeDGV.SelectionMode = DataGridViewSelectionMode.FullRowSelect;

            //  Build a 2-D string array; columnHeaderArray[][0] has
            //  the DGV column name; columnHeaderArray[][1] has the
            //  DGV column header text . . .

            String[][] columnHeaderArray = new String[][]
            {
                new String[] {"ROW_NUM", "ROW NUMBER"},
                new String[] {"CATEGORY_NAME", "CATEGORY NAME"},
                new String[] {"RECIPE_NAME", "RECIPE NAME"},
                new String[] {"RECIPE_TEXT", "RECIPE TEXT"},
                new String[] {"RECIPE_ID", "RECIPE ID"},
                new String[] {"CATEGORY_ID", "CATEGORY ID"},
                new String[] {"CREATE_DATE", "CREATE DATE"},
                new String[] {"LAST_UPDATE_DATE", "DATE OF LAST UPDATE"}
            };

            //  This array has the DGV column width values . . .

            int[] widthArray = new int[] { 95, 80, 140, 289, 65, 84, 165, 155 };

            //  Build out the RecipeDGV columns . . .

            for (i = 0; i < 8; i++)
            {
                this.RecipeDGV.Columns.Add(columnHeaderArray[i][0], columnHeaderArray[i][1]);
                this.RecipeDGV.Columns[i].HeaderCell.Style.Alignment = DataGridViewContentAlignment.MiddleCenter;
                this.RecipeDGV.Columns[i].SortMode = DataGridViewColumnSortMode.NotSortable;

                //  Set alignment for columns 0 and columns 4 to 7. Datagridview columns
                //  default to left aligned; to look for zero <-> false, cast 0 as a
                //  boolean . . .

                if (((i > 3) && (i < 6)) || (!Convert.ToBoolean(i)))
                {
                    this.RecipeDGV.Columns[i].DefaultCellStyle.Alignment = DataGridViewContentAlignment.MiddleRight;
                }

                this.RecipeDGV.Columns[i].Width = widthArray[i];
            }

            //  Build DGVRecordArray has a 1-D array OF 1-D string
            //  arrays - a jagged array . . .

            //  The original" values . . .

            //  RECIPE 1 COL 2  -> "A TESTED RECIPE"
            //  RECIPE 7 COL 2  -> "CHOCOLATE RECIPE"
            //  RECIPE 11 COL 2  -> "RECIPE RETESTING"

            String[][] DGVRecordArray = new String[][]
            {
                new String[] {"1", "CATEGORY_1", "-2", "The tested recipe goes here." + csNL + csNL + "It has only two lines.", "17", "500", "FEBRUARY 12, 2006", "JANUARY 25, 2008"},
                new String[] {"2", "CATEGORY_1", "RECIPE 25", "For RECIPE 25, look for three lines" + csNL + csNL + "here" + csNL + csNL + "and here.", "19", "500", "JANUARY 15, 2008 10:45:22", "APRIL 02, 2008"},
                new String[] {"3", "CATEGORY_1", "BISCUIT RECIPE", "This biscuit recipe worked well and it had" + csNL + csNL + "a few" + csNL + csNL + "lines.", "20", "500", "JANUARY 15, 2008 10:45:22", "JANUARY 15, 2008"},
                new String[] {"4", "CATEGORY_1", "PUBLISHED RECIPE", "A published recipe" + csNL + csNL + "with more lines" + csNL + csNL + "here" + csNL + csNL + "and here" + csNL + csNL + "and here.", "23", "500", "NOVEMBER 01, 2004", "JANUARY 19, 2008"},
                new String[] {"5", "CATEGORY_1", "RECIPE FOR STEW", "The stew recipe should have beef or lamb.", "27", "500", "MARCH 22, 2007", "APRIL 15, 2008"},
                new String[] {"6", "CATEGORY_1", "TESTED RECIPE", "Recipe testing done" + csNL + csNL + "for this" + csNL + csNL + "recipe" + csNL + csNL + "as verified records. . .", "29", "500", "JANUARY 11, 2008", "JANUARY 14, 2008"},
                new String[] {"7", "CATEGORY_1", "83.991", "Sample chocolate cake recipe" + csNL + csNL + "Line 2" + csNL + csNL + "Next line here.", "30", "500", "DECEMBER 10, 2007", "JANUARY 15, 2008"},
                new String[] {"8", "CATEGORY_1", "AAAAAAA TEST RECIPE", "This is a test." + csNL + csNL + "Another test." + csNL + csNL + "Another line." + csNL + csNL + "Yet another line." + csNL + csNL + "Line 4." + csNL + csNL + "Line 5." + csNL + csNL + "Line 6.", "4906", "500", "JANUARY 15, 2008", "JANUARY 15, 2008"},
                new String[] {"9", "CATEGORY_2", "COOKIE RECIPE", " One original cookie recipe" + csNL + csNL + "on multiple lines" + csNL + csNL + "of text.", "3378", "545", "OCTOBER 01, 2006", "JANUARY 15, 2008"},
                new String[] {"10", "CATEGORY_1", "RECIPE RETEST", "This is line 1." + csNL + csNL + "This is line 2." + csNL + "And line 3.", "4988", "500", "AUGUST 29, 2007", "JANUARY 15, 2008"},
                new String[] {"11", "CATEGORY_2", "83.992", "This is a retest." + csNL + csNL + "Line 1 1/2, and line 1 3/4." + csNL + csNL + "Line 2." + csNL + csNL + "Line 2.5 here!" + csNL + csNL + "Line 3." + csNL + csNL + "Line 4.", "4989", "545", "JULY 10, 2007", "MARCH 07, 2008"},
                new String[] {"12", "CATEGORY_2", "A TESTED RECIPE", "Retesting the application here." + csNL + csNL + "Line 2." + csNL + "Line 3." + csNL + csNL + "Line 5.", "4987", "545", "MAY 09, 2006", "JANUARY 15, 2008"},
                new String[] {"13", "CATEGORY_2", "A TESTED RECIPE", "For example" + csNL + csNL + "this is an example recipe" + csNL + csNL + "here" + csNL + csNL + "in this record", "4990", "545", "JUNE 2, 2003", "JUNE 25, 2008"},
                new String[] {"14", "CATEGORY_2", "POTENTIAL RECIPE", "This is line 1." + csNL + csNL + "This is line 2." + csNL + "Line 3." + csNL + csNL + "Line 4.5." + csNL + csNL + "Line 4!", "3245", "545", "APRIL 18, 2000", "JANUARY 15, 2008"}
            };

            //  Load the DGVRecordArray values into RecipeDGV . . .

            for (i = 0; i < 14; i++)
            {
                this.RecipeDGV.Rows.Add();
                for (j = 0; j < 8; j++)
                {
                    this.RecipeDGV.Rows[i].Cells[j].Value = (String)DGVRecordArray[i][j];
                }
            }

            this.RecipeDGV.ColumnHeadersHeightSizeMode = DataGridViewColumnHeadersHeightSizeMode.DisableResizing;
            this.RecipeDGV.RowHeadersVisible = false;
        }

        private void btn_exit_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private void btn_load_RTB_Click(object sender, EventArgs e)
        {
            if (this.RecipeDGV.SelectedRows.Count < 1)
            {
                //  Leave the method if RecipeDGV has no selected rows . . .

                MessageBox.Show("Please pick at least one row in the DataGridView.", "No DataGridView rows selected", MessageBoxButtons.OK);
                return;
            }

            DataGridViewSelectedRowCollection localDGVSRC;

            String recipe_text = "";
            String recipe_name = "";
            int i = 0, j;
            String page_separator_string;

            //   String page_separator_string will simulate a
            //   page break in the rich textbox text. Declare
            //   a new constant
            //
            //       vbNL
            //
            //   as a substitute for
            //
            //       vbNewLine
            //
            //   to save character volume here . . .

            page_separator_string = csNL + csNL + "                     ____________";
            page_separator_string += csNL + "         ________________________" + csNL;
            page_separator_string += "                     ____________" + csNL + csNL + csNL;

            localDGVSRC = this.RecipeDGV.SelectedRows;

            //   The combinedDGVRecordArray is a 1-D array of single DGV record arrays.
            //   Array indexing starts at zero (0), so subtract one from
            //   RecipeDGV.SelectedRows.Count . . .

            String[][] combinedDGVRecordArray = new String[this.RecipeDGV.SelectedRows.Count][];

            i = 0;

            //  Place all selected row cells in combinedDGVRecordArray and initialize
            //  i. Use variable i to loop through the selected DGV source rows . . .

            foreach (DataGridViewRow row in this.RecipeDGV.SelectedRows)
            {
                combinedDGVRecordArray[i] = new String[this.RecipeDGV.Columns.Count];

                for (j = 0; j < this.RecipeDGV.Columns.Count; j++)
                {
                    combinedDGVRecordArray[i][j] = (String)row.Cells[j].Value;
                }

                //   Increment i to move to the next selected DGV source row . . .

                i += 1;
            }

            //   Dim / new a ColumnSorter object. The class wants the column
            //   numbers as strings. The column numbering starts at 0 (zero)
            //   and to flag descending order for a column, prefix the number
            //   with a hyphen
            //
            //       -
            //
            //   character. Use this even for column 0 (zero) . . .

            //        ColumnSorter column_comparer = new ColumnSorter("1", "-0")

            ColumnSorter column_comparer = new ColumnSorter("1", "-0");// ("2") // ("6", "-0");

            Array.Sort(combinedDGVRecordArray, column_comparer);

            //  Loop through every picked row in recipeDGV. In the
            //  rows, Item(3) has the recipe text. Item(2) has the
            //  recipe name string. Add a character that simulates
            //  a hard page break after the recipe text. Add 1 to
            //  GetUpperBound because it is zero based . . .

            for (i = 0; i < (combinedDGVRecordArray.GetUpperBound(0) + 1); i++)
            {
                recipe_name = combinedDGVRecordArray[i][2];
                recipe_text += recipe_name + csNL + csNL + combinedDGVRecordArray[i][3] + page_separator_string;
            }

            //  Delete the last / ending page_separator_string component
            //  characters in the recipe text, place that text in the
            //  relevant form / control, and set controls / forms as
            //  appropriate . . .

            recipe_text = recipe_text.Substring(0, (recipe_text.Length - 113));

            //  New a textForm1 object, disable controls
            //  on this form, and call that textForm1
            //  object . . .

            textForm1 localTextForm1 = new textForm1();

            this.btn_exit.Enabled = false;
            this.btn_load_RTB.Enabled = false;

            localTextForm1.recipe_text = recipe_text;

            localTextForm1.Show();
        }

        private void CSharp_Demo_App_Activated(object sender, EventArgs e)
        {
            //  Enable the form controls . . .

            this.btn_exit.Enabled = true;
            this.btn_load_RTB.Enabled = true;
        }
    }
}