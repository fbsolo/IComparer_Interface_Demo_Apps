﻿namespace CSharp_Demo_App
{
    partial class CSharp_Demo_App
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.btn_load_RTB = new System.Windows.Forms.Button();
            this.btn_exit = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // btn_load_RTB
            // 
            this.btn_load_RTB.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Bold);
            this.btn_load_RTB.Location = new System.Drawing.Point(40, 523);
            this.btn_load_RTB.Name = "btn_load_RTB";
            this.btn_load_RTB.Size = new System.Drawing.Size(142, 52);
            this.btn_load_RTB.TabIndex = 0;
            this.btn_load_RTB.Text = "&Load RTB";
            this.btn_load_RTB.UseVisualStyleBackColor = true;
            this.btn_load_RTB.Click += new System.EventHandler(this.btn_load_RTB_Click);
            // 
            // btn_exit
            // 
            this.btn_exit.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Bold);
            this.btn_exit.Location = new System.Drawing.Point(683, 523);
            this.btn_exit.Name = "btn_exit";
            this.btn_exit.Size = new System.Drawing.Size(142, 52);
            this.btn_exit.TabIndex = 1;
            this.btn_exit.Text = "&Close";
            this.btn_exit.UseVisualStyleBackColor = true;
            this.btn_exit.Click += new System.EventHandler(this.btn_exit_Click);
            // 
            // CSharp_Demo_App
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(1049, 633);
            this.ControlBox = false;
            this.Controls.Add(this.btn_exit);
            this.Controls.Add(this.btn_load_RTB);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.Fixed3D;
            this.MaximizeBox = false;
            this.MinimizeBox = false;
            this.Name = "CSharp_Demo_App";
            this.Text = "CSharp_Demo_App";
            this.Activated += new System.EventHandler(this.CSharp_Demo_App_Activated);
            this.Load += new System.EventHandler(this.CSharp_Demo_App_Load);
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.Button btn_exit;
        public System.Windows.Forms.Button btn_load_RTB;
    }
}

