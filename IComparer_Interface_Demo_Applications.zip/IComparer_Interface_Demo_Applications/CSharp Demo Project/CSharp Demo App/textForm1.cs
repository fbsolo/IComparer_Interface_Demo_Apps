﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace CSharp_Demo_App
{
    public partial class textForm1 : Form
    {
        private RichTextBox localRTB = new RichTextBox();
        private String local_recipe_text;
        
        //   This property has the text value to place
        //   in the localRTB RichTextBox . . .

        public String recipe_text
        {
            set { local_recipe_text = value; }
        }
        
        private void textForm1_Load(object sender, EventArgs e)
        {

            this.Controls.Add(this.localRTB);
            this.localRTB.Size = new Size(983, 500);
            this.localRTB.ScrollBars = RichTextBoxScrollBars.Vertical;

            //  Set the form width . . .

            this.Width = 1100;

            //  Place the local_recipe_text property
            //  in the RichTextBox . . .

            this.localRTB.Text = this.local_recipe_text;
        }

        public void showForm()
        {
            this.Show();
        }

        public textForm1()
        {
            InitializeComponent();
        }

        private void btn_exit_Click(object sender, EventArgs e)
        {
            this.Close();
        }
    }
}
